const express=require('express');
const app=express();
const port=5000;



//path for rendering html files
const path=require("path");

//static file to enable css to show
app.use(express.static("views"))


//for accepting post form data
const bodyParser=require("express");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));


//nodemailer config
const nodemailer = require("nodemailer");



app.post("/sendmail", (req,res)=> {
    console.log(req.body);
    const { to , subject, message}=req.body;

    const transporter=nodemailer.createTransport(
        {
            service:"gmail",
            auth:{
                user: 'hanan.sa.202@gmail.com',
                pass: 'ctiqjfonkhoyzxqc'
            }
        })
        
    const mailOptions={
        from: req.body.email ,
        to: to,
        subject:subject,
        text:message
    }

    transporter.sendMail(mailOptions , (error, info) => {

        if(error) {
            console.log(error);
            res.json({ststus: "FAILED", message:"An error occurred!"});

        } else {
            console.log('Email sent ');
            res.sendFile(path.join(__dirname,"./views/success.html"));
            
        }
    } )

    })//end of post

app.get("/", (req, res) => {
    req.sendFile(path.join(__dirname,"./views/index.html"));
});

app.listen(port, ()=>{
    console.log("server running");
})



//require("dotenv").config();

// enable app on diffrent hosts to send req
//const cors=require("cors")
//app.use(cors());

//simple approach
// const transporter=nodemailer.createTransport({
//     service:"gmail",
//     auth:{
//         user:process.env.AUTH_EMAIL,
//         pass:process.env.AUTH_PASS
//     }
// })

// //
// const transporter_pro=nodemailer.createTransport({

//     service:"gmail",
//     auth:{
//         type: "OAuth2",
//         user: process.env.AUTH_EMAIL,
//         clientId: process.env.AUTH_CLIENT_ID,
//         clientSecret: process.env.AUTH_CLIENT_SECRET,
//         refreshToken: process.env.AUTH_REFRESH_TOKEN
         
//     }
// })

//testing nodemailer success
// transporter_pro.verify((error, success) => {
//     if(error){
//         console.log(error)
//     }else{
//         console.log("Ready for message");
//         console.log(success);
//     }
// }
// );

// app.post("/sendmail", (req,res)=> {
//     const { to , subject, message}=req.body;

//     const mailOptions={
//         from: process.env.AUTH_EMAIL,
//         to: to,
//         subject:subject,
//         text:message

//     }

//     transporter_pro
//     .sendMail(mailOptions)
//     .then( () => {
//         req.sendFile(path.join(__dirname,"./views/success.html"));
//     }
//     )//end then
//     .catch( (error) => {
//         console.log(error);
//         res.json({ststus: "FAILED", message:"An error occurred!"});
//     })
// })